#include "StdAfx.h"
#include "Cuenta.h"


Cuenta::Cuenta()
{
	iNoCuenta = -1;
	Saldo = 0;
	sDueno = "N/A";
	cTipoCuenta = 'A';
}

Cuenta::Cuenta(int iN, double dB, string sD)
{
	iNoCuenta = iN;
	Saldo = dB;
	sDueno = sD; // setDueno(sD); 
}
	
double Cuenta::calculaPagoAnual()
{
	double dPagoAnual = 2500;
	switch (cTipoCuenta)
	{
		case 'A':
			dPagoAnual += 1500;
			break;
		case 'C':
			dPagoAnual += 1000;
			break;
		case 'D':
			dPagoAnual += 500;
			break;
	}
	return dPagoAnual;
}

void Cuenta::deposita(double dDeposito)
{
	Saldo += dDeposito;
}

double Cuenta::getBalance()
{
	return Saldo;
}

string Cuenta::getDueno()
{
	return sDueno;
}

char Cuenta::getTipoCuenta()
{
	return cTipoCuenta;
}

int Cuenta::getNoCuenta()
{
	return iNoCuenta;
}

bool Cuenta::retira(double dRetiro)
{
	if (Saldo >= dRetiro)
	{
		Saldo -= dRetiro;
		return true;
	}
	else
	{
		return false;
	}
}

void Cuenta::setBalance(double dB)
{
	Saldo = dB;
}

void Cuenta::setDueno(string sD)
{
	sDueno = sD;
}

void Cuenta::setNoCuenta(int iN)
{
	iNoCuenta = iN;
}
