#pragma once
#include <iostream>
#include <string> // Manejar string
using namespace std;

class Cuenta
{
	private:
		int iNoCuenta;
		double Saldo;
		string sDueno;
		char cTipoCuenta;
	public:
		Cuenta(); //Constructor
		Cuenta(int, double, string); // Declaraci�n
		double calculaPagoAnual();
		void deposita(double);
		double getBalance();
		string getDueno();
		char getTipoCuenta();
		int getNoCuenta();
		bool retira(double);
		void setBalance(double);
		void setDueno(string);
		void setNoCuenta(int);
};



