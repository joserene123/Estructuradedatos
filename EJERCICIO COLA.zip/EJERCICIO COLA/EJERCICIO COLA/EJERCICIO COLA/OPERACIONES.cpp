#include "StdAfx.h"
#include "OPERACIONES.h"


OPERACIONES::OPERACIONES(void)
{
	COLA();
}
void OPERACIONES::Guardar_cola_grilla(DataGridView^  grilla_cola)
{
	int i;
	NODO nodito;
	i=0;
	COLA aux;
	aux=This_cola();
	grilla_cola->ColumnCount=Longitud_cola();
	grilla_cola->RowCount=2;
	while(aux.Cola_vacia()==false)
	{
	
		aux.Eliminar(nodito);
		grilla_cola->Rows[0]->Cells[i]->Value=System::Convert::ToString(nodito.Get_numero_proceso());
		grilla_cola->Rows[1]->Cells[i]->Value=marshal_as<System::String^>(nodito.Get_nombre_proceso());
		
	    i++;
	}
}

int OPERACIONES::Longitud_cola()
{
	int t=0;
	COLA aux;
	aux=This_cola();
	NODO nodito;
	while(aux.Cola_vacia()==false)
	{
	
	  aux.Eliminar(nodito);
	  //aux.Insertar(nodito);
	  t++;
	}
  // This_cola(aux);
   return t;
}

void OPERACIONES::Guardar_grilla_cola(DataGridView^  grilla_cola)
{
	int i;
	NODO nodito;
	i=0;
	while(i<grilla_cola->ColumnCount)
	{
	
		nodito.Set_numero_proceso(System::Convert::ToInt32(grilla_cola->Rows[0]->Cells[i]->Value));

		nodito.Set_nombre_proceso(marshal_as<std::string>(System::Convert::ToString(grilla_cola->Rows[1]->Cells[i]->Value)));
	
		Insertar(nodito);
	i++;
	}



}

void OPERACIONES::Eliminar_numero_pares()
{
	NODO elem;
	COLA aux;
	while(Cola_vacia()==false)
	{
	   Eliminar(elem);
	   if((elem.Get_numero_proceso()%2)!=0) { aux.Insertar(elem);}
	   
	}

	This_cola(aux);

}
/*void OPERACIONES::Eliminar_repetidos()
{
	NODO elem;
	COLA aux;
	while(Cola_vacia()==false)
	{
		Eliminar(elem);
		aux.Insertar(elem);
	}
	This_cola(aux);
}*/
void OPERACIONES::Eliminar_repetidos()
{
	NODO elem;
	COLA aux;
	while(Cola_vacia()==false)
	{
		Eliminar(elem);
		if((elem)==(elem)) { aux.Insertar(elem);}
	}

	This_cola(aux);
}