#include "StdAfx.h"
#include "COLA.h"


COLA::COLA(void)
{
	frente=-1;
	final=-1;
}
bool COLA::Cola_vacia()
{
	if(frente==final) { return true;}
	else { return false;}

}
	bool COLA::Cola_llena()
	{
		if(final==NC-1){ return true;}
		else {return false;}
	
	}
	bool COLA::Insertar(NODO nodito)
	{
		if(Cola_llena()==true) { return false;}
		else { final++;
		cola[final]=nodito;
		return true;
		}
	}
	bool COLA::Eliminar(NODO &nodito)
	{
	    if(Cola_vacia()==true) { return false;}
		else { frente++;
		nodito=cola[frente];
		return true;
		}
	
	}
	int  COLA::Get_frente()
	{
	   return frente+1;
	
	}

	COLA COLA::This_cola()
	{
	   return *this;
	}

void COLA::This_cola(COLA x)
{
	*this=x;

}