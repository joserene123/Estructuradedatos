#include <iostream>
#include <stdlib.h>

using namespace std;

class nodo {
public:
  int dato;
  string nombre;
  nodo *sig;
};

