#include "StdAfx.h"
#include "nodo.h"


nodo::nodo(void)
{
}


nodo::~nodo(void)
{
}
