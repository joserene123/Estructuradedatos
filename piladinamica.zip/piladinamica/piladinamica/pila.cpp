#include "StdAfx.h"
#include "pila.h"


pila::pila(void)
{
}


/*pila::~pila(void)
{
}*/
void pila::push() {
  int valor;
  string valor2;
  nodo * aux = new nodo;
       // ubica espacio de memoria para crear una instancia del nodo: operator new (nodo))
      // y entonces construye un objeto en el nuevo espacio ubicado
  system("cls");
  cout << "Ingresa el id del proceso: ";
  cin >> valor;
  cout << "Ingresa el nombre del proceso: ";
  cin.ignore();
  getline(cin, valor2);
  aux->dato = valor;
  aux->nombre = valor2;
  aux->sig = NULL;
       //Accede al elemento dato de nodo y le asigna valor.
  if (inicio != NULL)
    aux->sig = inicio;
  inicio = aux;
  cout << "Nuevo proceso insertado en la pila!\n";
  system("pause");
}

void pila::pop() {
  nodo * temp = new nodo;
  if (inicio == NULL) {
    system("cls");
    cout << "\nLa pila esta vacia!\n\n";
    system("pause");
  } else {
    temp = inicio;
    inicio = inicio->sig;
    system("cls");
    cout << "\nEl proceso eliminado es: " << temp->dato << " - " << temp->nombre << "\n" << endl;
    delete temp;
    system("pause");
  }
}

void pila::show() {
  nodo * aux1 = inicio;
  if (inicio == NULL) {
    system("cls");
    cout << "\nLa pila esta vacia!\n\n";
    system("pause");
  } else {
    system("cls");
    cout << "Procesos:\n" << endl;
    while (aux1 != NULL) {
      cout << aux1->dato << " - " << aux1->nombre << "\n" << endl;
      aux1 = aux1->sig;
    }
    system("pause");
  }
}

void pila::top() {
  nodo * aux1 = inicio;
  if (inicio == NULL) {
    system("cls");
    cout << "\nLa pila esta vacia!\n\n";
    system("pause");
  } else {
    system("cls");
    cout << "Proceso TOP:\n" << endl;
    cout << aux1->dato << " - " << aux1->nombre << "\n" << endl;
    system("pause");
  }
}

void pila::size() {
  nodo * aux1 = inicio;
  if (inicio == NULL) {
    system("cls");
    cout << "\nLa pila esta vacia!\n\n";
    system("pause");
  } else {
    int contador = 0;
    while (aux1) {
      contador++;
      aux1 = aux1->sig;
    }
    system("cls");
    cout << "El tamano de la pila es: '" << contador << "'\n" << endl;
    system("pause");
  }
}