#pragma once

class pila {
  nodo *inicio;
public:
  pila(){
    inicio=NULL;
  }
  void push();
  void pop();
  void show();
  void top();
  void size();
};