#include "StdAfx.h"
#include "Mercaderia.h"


Mercaderia::Mercaderia(void)
{
}
void Mercaderia::Set_Producto(string prod)
{
	producto=prod;
}
string Mercaderia::Get_Producto()
{
	return producto;
}
void Mercaderia::Set_Ventas(double ven)
{
	ventas=ven;
}
double Mercaderia::Get_Ventas()
{
	return ventas;
}
void Mercaderia::Set_Costodeventas(double cost)
{
	costodeventas=cost;
}
double Mercaderia::Get_Costodeventas()
{
	return costodeventas;
}
void Mercaderia::Set_Cantidad(double can)
{
	cantidad=can;
}
double Mercaderia::Get_Cantidad()
{
	return cantidad;
}
void Mercaderia::Set_Ganancias(double gan)
{
	ganancias=gan;
	gan=ventas-costodeventas;
}
double Mercaderia::Get_Ganancias()
{
	return ganancias;
}