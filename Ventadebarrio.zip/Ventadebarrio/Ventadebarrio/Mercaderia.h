#pragma once
#include <iostream>
#include <string.h>
using namespace std;
class Mercaderia
{
private:
	string producto;
	double ventas;
	double costodeventas;
	double cantidad;
	double ganancias;

public:
	Mercaderia(void);
	void Set_Producto(string prod);
	string Get_Producto();
	void Set_Ventas(double ven);
	double Get_Ventas();
	void Set_Costodeventas(double cost);
	double Get_Costodeventas();
	void Set_Cantidad(double can);
	double Get_Cantidad();
	void Set_Ganancias(double gan);
	double Get_Ganancias();

};

