// subredes.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include "stdafx.h"
#include <iostream>
int poten(int n1, int y)
using namespace stf;


int main(void)
{int n1, n2,y,t;
cout<<"Digite la base de su operacion"<<endl; cin>>n1;
cout<<"digite el exponente de su operacion"<<endl; cin>>y

cout <<"el resultado es: "<<t<<endl;
	return 0;
}

int poten(int n1, int y)
{int t;
	t=pow(n1,y)
return(t);
}

