


#include "stdafx.h"
#include <iostream>
#include "conio.h"
#include "multiplo.h"  

#define MAX 100

using namespace std;

void main(){

	int vec[MAX], n,  op; 
	multiplo multiplo1;  
	do {
		cout<<"Ingrese la cantidad de elementos: ";
		cin>>n;
	} while ((n>MAX) || (n<=0));
	do{
		cout<<"-----       M E N U        -----"<<endl;
		cout<<"|1.- Cargar elemntos            |"<<endl;
		cout<<"|2.- multiplo de 3            |"<<endl;
		cout<<"|0.- Salir                     |"<<endl;
		cout<<"--------------------------------"<<endl;
		cout<<" Elija una opcion"<<endl;
		cin>>op;
		switch(op){
		case 1:
			cout<<"introducir elementos: "<<endl;
			multiplo1.cargarVector(vec, n);  
			break;
		case 2:
			multiplo1.ordenarVector(vec, n);
			break;
		case 0: 
			cout<<"Salir"<<endl;
			break;
		default:
			cout<<"Error: Opcion no valida..."<<endl;
			break;
		}
	}while(op!=0);
}
