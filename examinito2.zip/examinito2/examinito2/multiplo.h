#pragma once
class multiplo
{
private:
	int vec[100], n;
public:
	multiplo(void); // constructor
	~multiplo(void); //destructor

	void cargarVector(int vec[], int n); 
	void mostrarVector(int vec[], int n);
	void ordenarVector(int vec[], int n);
};
