#include "StdAfx.h"
#include <iostream>
#include "multiplo.h"

using namespace std;

multiplo::multiplo(void)
{
	vec[100]=0;
	n=0;
}


multiplo::~multiplo(void)
{
}

void multiplo::cargarVector(int vec[], int n){
	for(int i=0;i<n;i++){
		cout<<"vec["<<i<<"] =" ;
		cin>>vec[i];
	}
}
void multiplo::mostrarVector(int vec[], int n){
	for(int i=0;i<n;i++){
		cout<<vec[i]<<", ";
	}
	cout<<endl;
}

void multiplo::ordenarVector(int vec[], int n){
	for (int i =1;i<=n;i++){
		if(i%3==0)
			cout<<"es multiplo de 3"<<i<<endl;
	}
}