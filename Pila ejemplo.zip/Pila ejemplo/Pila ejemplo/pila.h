#pragma once
#define MAX 10


class pila
{
private:
          int pila[MAX];
          int cima;
        
public:
          pila(void);
          bool Apilar(TipoDato &elemento);
          bool Desapilar();
          bool CimaPila(TipoDato &elemento);
          void LimpiarPila();
          void VerPila();          
          bool PilaVacia();
          bool Iguales(pila p);
   
};

