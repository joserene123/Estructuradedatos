#pragma once

namespace Pilaejemplo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnDefinir;
	protected: 
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::TextBox^  txtDefinir;
	private: System::Windows::Forms::TextBox^  txtIngresar;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->txtDefinir = (gcnew System::Windows::Forms::TextBox());
			this->txtIngresar = (gcnew System::Windows::Forms::TextBox());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(197, 24);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(75, 23);
			this->btnDefinir->TabIndex = 0;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(197, 94);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(75, 23);
			this->btnIngresar->TabIndex = 2;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			// 
			// txtDefinir
			// 
			this->txtDefinir->Location = System::Drawing::Point(77, 27);
			this->txtDefinir->Name = L"txtDefinir";
			this->txtDefinir->Size = System::Drawing::Size(100, 20);
			this->txtDefinir->TabIndex = 3;
			this->txtDefinir->TextChanged += gcnew System::EventHandler(this, &Form1::txtDefinir_TextChanged);
			// 
			// txtIngresar
			// 
			this->txtIngresar->Location = System::Drawing::Point(77, 94);
			this->txtIngresar->Name = L"txtIngresar";
			this->txtIngresar->Size = System::Drawing::Size(100, 20);
			this->txtIngresar->TabIndex = 3;
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(77, 143);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(177, 106);
			this->Grid->TabIndex = 4;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->txtIngresar);
			this->Controls->Add(this->txtDefinir);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnDefinir);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void txtDefinir_TextChanged(System::Object^  sender, System::EventArgs^  e) {
			 }
};
}

