#pragma once
#define MAX 10
class Pila
{
private:
	int cima;
	int P[MAX];

public:
	Pila(void);
	virtual ~Pila(void);

};

