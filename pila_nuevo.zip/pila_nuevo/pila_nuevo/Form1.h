#pragma once

namespace pila_nuevo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtDesapilar;
	protected: 
	private: System::Windows::Forms::TextBox^  txtApilar;
	private: System::Windows::Forms::Button^  btnApilar;
	private: System::Windows::Forms::Button^  btnDesapilar;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtDesapilar = (gcnew System::Windows::Forms::TextBox());
			this->txtApilar = (gcnew System::Windows::Forms::TextBox());
			this->btnApilar = (gcnew System::Windows::Forms::Button());
			this->btnDesapilar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// txtDesapilar
			// 
			this->txtDesapilar->Location = System::Drawing::Point(120, 146);
			this->txtDesapilar->Name = L"txtDesapilar";
			this->txtDesapilar->Size = System::Drawing::Size(100, 20);
			this->txtDesapilar->TabIndex = 0;
			// 
			// txtApilar
			// 
			this->txtApilar->Location = System::Drawing::Point(120, 52);
			this->txtApilar->Name = L"txtApilar";
			this->txtApilar->Size = System::Drawing::Size(100, 20);
			this->txtApilar->TabIndex = 0;
			// 
			// btnApilar
			// 
			this->btnApilar->Location = System::Drawing::Point(299, 50);
			this->btnApilar->Name = L"btnApilar";
			this->btnApilar->Size = System::Drawing::Size(75, 23);
			this->btnApilar->TabIndex = 1;
			this->btnApilar->Text = L"Apilar";
			this->btnApilar->UseVisualStyleBackColor = true;
			// 
			// btnDesapilar
			// 
			this->btnDesapilar->Location = System::Drawing::Point(299, 146);
			this->btnDesapilar->Name = L"btnDesapilar";
			this->btnDesapilar->Size = System::Drawing::Size(75, 23);
			this->btnDesapilar->TabIndex = 1;
			this->btnDesapilar->Text = L"Desapilar";
			this->btnDesapilar->UseVisualStyleBackColor = true;
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(134, 207);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(240, 150);
			this->Grid->TabIndex = 2;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(444, 390);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnDesapilar);
			this->Controls->Add(this->btnApilar);
			this->Controls->Add(this->txtApilar);
			this->Controls->Add(this->txtDesapilar);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	};
}

