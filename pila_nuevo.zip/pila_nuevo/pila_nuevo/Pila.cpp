#include "StdAfx.h"
#include "Pila.h"


Pila::Pila(void)
{
}


Pila::~Pila(void)
{
}
