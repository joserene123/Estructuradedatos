#include "StdAfx.h"
#include "matrices.h"
#include <iostream>
#include "conio.h"
using namespace std;


matrices::matrices(int _n, int _m)
{
	n=_n;
	m=_m;
}
matrices::matrices(void)
{
}


matrices::~matrices(void)
{
}
void matrices::cargar()
{
	for(int i=0; i<n; i++)
	{
		for(int j=0; j<n; j++)
		{
			cout<<"M[ "<<i<<"] ["<<j<<"]= ";
			cin>>Mat[i][j];
		}
	}
}
bool matrices::verifcuadrada()
{
	if(n==m)
		return true;
	else
		return false;
}
void matrices::mostrar()
{}
void matrices::mostrarDiagonal()
{
	for(int i=0; i<n; i++)
		cout<<Mat[i][i];
}
int matrices::sumaDiagonal()
{
	int aux=0;
	for(int i=0; i<n;i++)
		aux=aux + Mat[i][i];
	return aux;
}
int matrices::devolverfila()
{
	return n;
}
void matrices::sumarmatrices(matrices mat1, matrices mat2)
{
	for(int i=0; i<mat1.n; i++)
		for(int j=0; j<mat1.m; j++)
			Mat[i][j]=mat1.Mat[i][j]+ mat2.Mat[i][j];
	n=mat1.n;
	m=mat1.m;
}