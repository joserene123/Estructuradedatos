#pragma once
class matrices
{
private:
	int Mat[10][10];
	int n;
	int m;
public:
	matrices(int _n, int _m);
	matrices();
	~matrices(void);
	void cargar();
	bool verifcuadrada();
	void mostrar();
	void mostrarDiagonal();
	int sumaDiagonal();
	int devolverfila();
	void sumarmatrices(matrices mat1, matrices mat2);

};

