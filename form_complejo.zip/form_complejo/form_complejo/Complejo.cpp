#include "StdAfx.h"
#include "Complejo.h"


CComplejo::CComplejo(void)
{
}

void CComplejo::Set_real(double r)
{ 
	real=r;
}

void CComplejo::Set_imag(double i)
{
	imag=i;
}

double CComplejo::Get_real()
{
	return real;
}

double CComplejo::Get_imag()
{
	return imag;
}

void CComplejo::suma(const CComplejo a, const CComplejo b)
{
	real=a.real+b.real;
	imag=b.imag+b.imag;
}
