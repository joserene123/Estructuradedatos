#include "StdAfx.h"
#include "Nodo.h"


Nodo::Nodo(void)
{
}


Nodo::~Nodo(void)
{
}
